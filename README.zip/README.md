﻿**Report for Assignment 1**

**Project chosen:**

**Name:** wemake-python-styleguide (the strictest and most opinionated python linter ever!) **URL:** <https://github.com/wemake-services/wemake-python-styleguide>

**Number of lines of code and the tool used to count it:**

In order to count the total number of lines of code, the “lizard” tool was used in our clone public repository. As it can be observed from the screenshots below, the whole project consists of 50458 lines of code.

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.001.jpeg)

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.002.jpeg)

**Programming language:** Python **Coverage measurement: Existing tool:**

The code coverage tool that was used is “coverage.py”, which is a popular tool for measuring code coverage in Python projects. In order to execute this tool, we first need to navigate to our project directory, and then with the command “coverage run -m pytest tests” we can display the coverage results onto the command line interface. As it can be observed from the report, the code coverage is 43.25%.

![ref1]

**Your own coverage tool: Marilia Nikolaou:**

**Function 1:** 

Name: **\_almost\_swapped**

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/blob/master/we make_python_styleguide/visitors/ast/statements.py](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/blob/master/wemake_python_styleguide/visitors/ast/statements.py)

Screenshot of the coverage measurements: 

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.004.jpeg)

**Function 2:**

Name: **\_check\_heterogeneous\_operators**

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/blob/master/we make_python_styleguide/visitors/ast/compares.py](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/blob/master/wemake_python_styleguide/visitors/ast/compares.py)

Screenshot of the coverage measurements:

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.005.jpeg)

**Melani Evangelou:**

**Function 1:** 

Name: **process\_child\_nodes**

Commit Link: https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/cf63f3c 5d17299256fc0dd054be0c12251c173c6

Screenshot of the coverage measurements: 

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.006.jpeg)

**Function 2:** 

Name: **\_check\_ordering**

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/596735 1c4e5a335a94bad9345aaa593a67485319](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/5967351c4e5a335a94bad9345aaa593a67485319)

Screenshot of the coverage measurements: 

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.007.jpeg)

**Christos Mouskallis:**

**Function 1:** Name:**\_check\_new\_decorator\_syntax**

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/c8e21b 80e25c9e114592a4c473d82284e74a80ed](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/c8e21b80e25c9e114592a4c473d82284e74a80ed)

Screenshot of the coverage measurements: 

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.008.jpeg)

**Function 2:** 

Name: **\_check\_boolean\_arguments**

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/b5decf7 2338d4d8a9f6046b0a62a58a649d94c51](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/b5decf72338d4d8a9f6046b0a62a58a649d94c51)

Screenshot of the coverage measurements: 


![ref2]

**Coverage improvement: Marilia Nikolaou:**

**Test 1:** 

Name: def test\_wrong\_swapped\_variables

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/blob/master/tes ts/test_visitors/test_ast/test_statements/test_almost_swapped.py](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/blob/master/tests/test_visitors/test_ast/test_statements/test_almost_swapped.py)

Old coverage results: 

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.010.jpeg)

New coverage results:

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.011.jpeg)

The branch coverage in the function **“\_almost\_swapped”** has improved significantly, because as it can be seen from the screenshots above, initially the coverage is 85.71%, 71.43%, and 28.57% in different test cases, and the final test case has branch coverage 100%. This indicates, that the addition of the new test case, covers all the previously untested branches and all the branches are hit successfully.

**Test 2:**

Name: def test\_correct\_compare\_operators

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/blob/master/tes ts/test_visitors/test_ast/test_compares/test_heterogenous_compare.py](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/blob/master/tests/test_visitors/test_ast/test_compares/test_heterogenous_compare.py)

Old coverage results:

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.012.jpeg)

New coverage results:

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.013.jpeg)

The branch coverage in the function **“\_check\_heterogeneous\_operators”** has improved significantly, because as it can be seen from the screenshots above, initially the coverage is 60% in different test cases, and the final test case has branch coverage 80%. This indicates, that the addition of the new test case, covers all the untested branches instead of the first one.

**Melani Evangelou:**

**Test 1:** 

Name: **test\_cognitive\_complexity**

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/b2216d 6b1f99e5f13a403de8fc11d70f5600f830](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/b2216d6b1f99e5f13a403de8fc11d70f5600f830)

Old coverage results: ![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.014.jpeg)

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.015.jpeg)

The branch coverage in the function “**test\_cognitive\_complexity**”** has improved significantly, because as it can be seen from the screenshots above, initially the highest coverage shown in different test cases of the test we are examining was 20% , and now I have created a test case that has branch coverage 100%. The reason why the coverage was improved significantly is because the already existing test case did not include a try-catch block that was necessary to hit this branch if isinstance(node, ast.Try) and consequently the one nested inside of it.

**Test 2:** 

Name: **test\_compare\_variables**

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/491b99 f51a1a4cdec4cfe9f40b68454916d2f053](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/491b99f51a1a4cdec4cfe9f40b68454916d2f053)

Old coverage results: 

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.016.jpeg)

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.017.jpeg)

The branch coverage in the function “**test\_compare\_variables**”** has improved, because as it can be seen from the screenshots above, initially branch 3 was never hit and now I have created a test case that manages to hit it. The reason why the coverage has improved it is because we needed to include a special cade node like in or not in  in order to hit  

branch3 if self.\_is\_special\_case(node). **Christos Mouskallis:**

**Test 1:** 

Name: test\_new\_style\_decorators.py

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/c8e21b 80e25c9e114592a4c473d82284e74a80ed](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/c8e21b80e25c9e114592a4c473d82284e74a80ed)

Old coverage results: 

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.018.jpeg)

New coverage results:


![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.019.jpeg)

The branch coverage in the function “**test\_new\_style\_decorators.py**”** has improved, because as it can be seen from the screenshots above, initially branch 2 was never hit and now I have created a test case that manages to hit it. Initially, the branch coverage was 66.67% and now with hitting branch 2 it went up to 100%.

**Test 2:** 

Name: test\_boolean\_args.py

Commit Link: [https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/b5decf7 2338d4d8a9f6046b0a62a58a649d94c51](https://github.com/marilianikolaou/wemake-python-styleguide-assignment-1-/commit/b5decf72338d4d8a9f6046b0a62a58a649d94c51)

Old coverage results: 

![ref2]

New coverage results:

![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.020.jpeg)

The branch coverage in the function “**test\_boolean\_args.py**”** has improved, because as it can be seen from the screenshots above, initially branch 4 was never hit and now I have created a test case that manages to hit it. Initially, the branch coverage was 57.14% and now with hitting branch 4 it went up to 71.43%.

**Overall:**

Old coverage results:![ref3]

New coverage results:![](Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.022.png)

**Statement of individual contributions:**

**Marilia Nikolaou:** ran the “lizard” tool to measure the number of lines of code, measured the coverage for the functions **“\_almost\_swapped”**, and **“\_check\_heterogeneous\_operators”**, and improved the test cases **“test\_wrong\_swapped\_variables”**, and **“test\_correct\_compare\_operators”** for the functions respectively.


**Melani Evangelou:** 

measured the coverage for the functions **“process\_child\_nodes”**, and “**\_check\_ordering**”, and improved the test cases “**test\_cognitive\_complexity**”, and “**test\_compare\_variables**” for the functions respectively.

**Christos Mouskallis:**

measured the coverage for the functions **“\_check\_new\_decorator\_syntax”**, and “

**\_check\_boolean\_arguments**”, and improved the test cases “**test\_new\_style\_decorators.py**”, and “**test\_boolean\_args.py**” for the functions respectively.

[ref1]: Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.003.png
[ref2]: Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.009.jpeg
[ref3]: Aspose.Words.919d47e9-6083-4f14-82d0-d2bafe3d06e5.021.png
